import mysql2 from 'mysql2/promise'

export const pool = mysql2.createPool({
    host: "localhost",
    user: "root",
    password: "",
    port: 3306,
    database: "api_rest_node"
})







