import express from 'express'
import router_gamer from './routes/routes_games.js'
import router_index from './routes/index_routes.js'

const app = express()
app.use(express.json())

const port = 3000
app.listen(port, () => console.log(`127.0.0.1 listening on port ${port}!`))

app.use(router_index)
app.use(router_gamer)

app.use((req, res, next) => {
    res.status(404).json({
        message:"URL not found"
    })
})

